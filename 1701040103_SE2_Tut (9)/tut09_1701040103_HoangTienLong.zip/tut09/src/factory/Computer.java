package factory;

// Create the Computer class that extends Course abstract class 
class  Computer extends Courses{  
    //@override  
    public void getDuration(){  
         duration=8;             // duration in semesters            
    }  
    public void getFeePerSemester(){
fee = 3000;             // fee in dollars   
    }
}//end of Computer class.  
