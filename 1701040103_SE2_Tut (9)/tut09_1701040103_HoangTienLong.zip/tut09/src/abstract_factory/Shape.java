package abstract_factory;

// Create the Shape interface
public interface Shape {
	void draw();
}
