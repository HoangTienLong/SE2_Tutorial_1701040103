package factory;

// Creating the Health class that extends Course abstract class 
class  Health extends Courses{  
    //@override  
    public void getDuration(){  
         duration=10;             // duration in semesters            
    }  
    public void getFeePerSemester(){
fee = 5000;             // fee in dollars   
    }
}